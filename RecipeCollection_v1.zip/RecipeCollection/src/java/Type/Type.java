package Type;

/**
 *
 * @author johnkmnguyen
 */
public class Type 
{
    private String recipeID;
    private String type;

    public String getRecipeID() {
        return recipeID;
    }

    public void setRecipeID(String recipeID) {
        this.recipeID = recipeID;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    
    
}


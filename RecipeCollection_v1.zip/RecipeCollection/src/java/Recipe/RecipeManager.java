/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Recipe;

import Ingredient.Ingredient;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

/**
 *
 * @author Haba
 */
@ManagedBean(name = "RecipeManager")
@SessionScoped
public class RecipeManager implements Serializable {

    private static final long serialVersionUID = 1L;
    String book;
    String search = "";
    int max = 0, rows = 0, myIndex = -1;
    List<Recipe> recs = new ArrayList<>();
    List<Recipe> recsByName = new ArrayList<>();
    PreparedStatement ps = null;
    Connection con = null;
    ResultSet rs = null;
    Recipe thisRecipe = new Recipe();
    Recipe newRecipe = new Recipe();
    String myName = "";
    ArrayList<String> asd = new ArrayList<String>();
    List mySearch = new ArrayList<Recipe>();
    String action = "";
    boolean view = false, br = false;
    List<Ingredient> myIngre = new ArrayList<Ingredient>();
    String ingreName, ingreUnit;
    int ingreAmount;
    String sortby = "0";

    /**
     * Creates a new instance of Recipe
     */
    public RecipeManager() {
        max = 0;
        rows = 0;
        Recipe thisRecipe = new Recipe();
        newRecipe = new Recipe();
        myName = "";
        PreparedStatement ps = null;
        Connection con = null;
        ResultSet rs = null;
        init();
    }

    public List<Recipe> getRecsByName() {
        recsByName = new ArrayList<Recipe>();
        for (int i = 0; i < recs.size(); i++) {
            recsByName.add(recs.get(i));
        }
        int j;
        boolean flag = true;   // set flag to true to begin first pass
        Recipe temp;   //holding variable
        while (flag) {
            flag = false;    //set flag to false awaiting a possible swap
            for (j = 0; j < recsByName.size() - 1; j++) {
                if (recsByName.get(j).compareByName(recsByName.get(j + 1)) < 0) // change to > for ascending sort
                {
//                    temp = recsByName.get(j);                //swap elements
                    Collections.swap(recsByName, j, j + 1);
//                    recsByName.set(j, temp);
                    flag = true;              //shows a swap occurred  
                }
            }
        }
        return recsByName;
    }

    public void setRecsByName(List<Recipe> recsByName) {
        this.recsByName = recsByName;
    }

    public String getSortby() {
        return sortby;
    }

    public void setSortby(String sortby) {
        this.sortby = sortby;
    }

    public String getIngreName() {
        return ingreName;
    }

    public void setIngreName(String ingreName) {
        this.ingreName = ingreName;
    }

    public String getIngreUnit() {
        return ingreUnit;
    }

    public void setIngreUnit(String ingreUnit) {
        this.ingreUnit = ingreUnit;
    }

    public int getIngreAmount() {
        return ingreAmount;
    }

    public void setIngreAmount(int ingreAmount) {
        this.ingreAmount = ingreAmount;
    }

    public List<Ingredient> getMyIngre() {
        myIngre = new ArrayList<Ingredient>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/yeet?zeroDateTimeBehavior=convertToNull", "root", "1234");
            String sql = "select * from ingredient WHERE recipeID=" + thisRecipe.getRecipeID();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Ingredient ingre = new Ingredient();
                ingre.setrName(rs.getString("rName"));
                ingre.setAmount(rs.getInt("amount"));
                ingre.setUnit(rs.getString("unit"));
                myIngre.add(ingre);
            }
        } catch (ClassNotFoundException | SQLException e) {
        }
        return myIngre;
    }

    public void setMyIngre(List<Ingredient> myIngre) {
        this.myIngre = myIngre;
    }

    public String getAction() {
        FacesContext fc = FacesContext.getCurrentInstance();
        Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
        action = params.get("book");
        for (int i = 0; i < recs.size(); i++) {
            if (recs.get(i).getRecipeName().compareTo(action) == 0) {
                thisRecipe = recs.get(i);
            }
        }
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public List getMySearch() {
        return mySearch;
    }

    public void setMySearch(List mySearch) {
        this.mySearch = mySearch;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public Recipe getNewRecipe() {
        return newRecipe;
    }

    public void setNewRecipe(Recipe r) {
        newRecipe = r;
    }

    public int getMax() {
        max = 0;
        return getRecs().size();
    }

    public int getRows() {
        rows = 0;
        return (int) recs.size();
    }

    public List<Recipe> getRecs() {
        if (sortby.equals("0"))
            return recs;
        else if (sortby.equals("1"))
            return getRecsByName();
        return null;
    }

    public String getView(String name) {
        return "/Recipe/RecipeView";
    }

    public String getMyName() {
        return myName;
    }

    public Recipe getThisRecipe() {
        if (view) {
            getAction();
        }
        return thisRecipe;
    }

    public void setThisRecipe(Recipe r) {
        thisRecipe = r;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public String getBook() {
        return book;
    }

    public int getMyIndex() {
        return myIndex;
    }

    public ArrayList<String> getAsd() {
        return asd;
    }

    public String indexview() {
        view = true;
        return "/Recipe/RecipeView";
    }

    public String editview() {
        return "/Recipe/RecipeView";
    }

    public String edit() {
        view = false;
        br = true;
        return "/Recipe/RecipeEdit";
    }

    public String save() {
        try
        {
            System.out.println("YOU SUKKKKK");
            InputStream in = newRecipe.getUploadImage().getInputStream();
            
            File f = new File("/Users/johnkmnguyen/Desktop/CookBook_v7 new n improved/RecipeCollection/web/" 
                    + newRecipe.getUploadImage().getSubmittedFileName());    
            f.createNewFile();
            FileOutputStream out = new FileOutputStream(f);
            
            byte[] buffer = new byte[1024];
            int length;
            
            while((length = in.read(buffer)) > 0)
            {
                out.write(buffer, 0, length);
            }
            
            out.close();
            in.close();
        }catch(IOException e)
        {
            System.out.println("LOL DOESNT WORK");
            e.printStackTrace(System.out);
        }
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/yeet?zeroDateTimeBehavior=convertToNull", "root", "1234");
            String sql = "INSERT INTO recipe (userName,pushlishedDate,recipeName,description,steps,recipeID,image) "
                    + "VALUES (?,?,?,?,?,?,?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, newRecipe.getUserName());
            String date = fmt.format(newRecipe.getPushlishedDate());
            java.sql.Date dt = java.sql.Date.valueOf(date);
            ps.setDate(2, dt);
            ps.setString(3, newRecipe.getRecipeName());
            ps.setString(4, newRecipe.getDescription());
            ps.setString(5, newRecipe.getSteps());
            ps.setString(6, newRecipe.getRecipeID());
            ps.setString(7, newRecipe.getUploadImage().getSubmittedFileName());
            int i = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            /* Lazy */
        }
        newRecipe = new Recipe();
        init();
//        newRecipe = new Recipe();
         return "/faces/index?faces-redirect=true";
    }

    public String update() {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/yeet?zeroDateTimeBehavior=convertToNull", "root", "1234");
            String sql = "UPDATE Recipe "
                    + "SET recipeName=?,description=?,steps=?,image=?"
                    + "WHERE recipeID=" + thisRecipe.getRecipeID();
            ps = con.prepareStatement(sql);
            ps.setString(1, thisRecipe.getRecipeName());
            ps.setString(2, thisRecipe.getDescription());
            ps.setString(3, thisRecipe.getSteps());
            ps.setString(4, thisRecipe.getImage());
            int i = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            /* Lazy */
        }
        init();
        return "/Recipe/RecipeView";
    }

    public String searching() {
        mySearch = new ArrayList<Recipe>();
        for (int i = 0; i < recs.size(); i++) {
            if (recs.get(i).getRecipeName().toLowerCase().contains(search.toLowerCase())) {
                mySearch.add(recs.get(i));
            }
        }
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/yeet?zeroDateTimeBehavior=convertToNull", "root", "1234");
            String sql = "select * from ingredient WHERE rName=?";
            ps = con.prepareStatement(sql);
            ps.setString(1, search);
            rs = ps.executeQuery();
            while (rs.next()) {
                for (int i = 0; i < recs.size(); i++) {
                    if (recs.get(i).getRecipeID().equals(rs.getString("recipeID"))) {
                        mySearch.add(recs.get(i));
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/yeet?zeroDateTimeBehavior=convertToNull", "root", "1234");
            String sql = "select * from recType WHERE typeName=?";
            ps = con.prepareStatement(sql);
            ps.setString(1, search);
            rs = ps.executeQuery();
            while (rs.next()) {
                for (int i = 0; i < recs.size(); i++) {
                    if (recs.get(i).getRecipeID().equals(rs.getString("recipeID")) && !mySearch.contains(recs.get(i))) {
                        mySearch.add(recs.get(i));
                        
                    }
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        
        search = "";
        return "/search.xhtml?faces-redirect=true";
    }
    public String delete() {
      try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/yeet?zeroDateTimeBehavior=convertToNull", "root", "1234");
            String sql = "delete from recipe where recipeName=?";
            ps = con.prepareStatement(sql);
            ps.setString(1, thisRecipe.getRecipeName());
            int i = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        recs.remove(thisRecipe);
        return "/index?faces-redirect=true";
    }
    
    public String deleteIngre(Ingredient ing) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/yeet?zeroDateTimeBehavior=convertToNull", "root", "1234");
            String sql = "delete from ingredient where rName=?";
            ps = con.prepareStatement(sql);
            ps.setString(1, ing.getrName());
            int i = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        myIngre.remove(ing);
        return null;
    }

    public String insertIngre() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/yeet?zeroDateTimeBehavior=convertToNull", "root", "1234");
            String sql = "INSERT INTO ingredient (recipeID, rName, amount, unit) VALUES(?,?,?,?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, thisRecipe.getRecipeID());
            ps.setString(2, ingreName);
            ps.setInt(3, ingreAmount);
            ps.setString(4, ingreUnit);
            int i = ps.executeUpdate();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        Ingredient iningre = new Ingredient(ingreName, ingreAmount, ingreUnit);
        myIngre.add(iningre);
        ingreAmount = 0;
        ingreUnit = "";
        ingreName = "";
        return null;
    }

    public List sortByID() {
        Collections.sort(recs, new Comparator<Recipe>() {
            @Override
            public int compare(Recipe r1, Recipe r2) {
                return r1.getRecipeID().compareTo(r2.getRecipeID());
            }
        });
        return recs;
    }

    public void init() {
        recs = new ArrayList<Recipe>();
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/yeet?zeroDateTimeBehavior=convertToNull", "root", "1234");
            String sql = "select * from recipe";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                Recipe rec = new Recipe();
                rec.setUserName(rs.getString("userName"));
                rec.setPushlishedDate(rs.getDate("pushlishedDate"));
                rec.setRecipeName(rs.getString("recipeName"));
                rec.setDescription(rs.getString("description"));
                rec.setSteps(rs.getString("steps"));
                rec.setRecipeID(rs.getString("recipeID"));
                rec.setImage(rs.getString("Image"));
                recs.add(rec);
            }
        } catch (ClassNotFoundException | SQLException e) {
        }
    }
}

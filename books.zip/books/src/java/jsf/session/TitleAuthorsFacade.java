/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jsf.session;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import jpa.entities.TitleAuthors;

/**
 *
 * @author Chi Phan
 */
@Stateless
public class TitleAuthorsFacade extends AbstractFacade<TitleAuthors> {

    @PersistenceContext(unitName = "booksPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public TitleAuthorsFacade() {
        super(TitleAuthors.class);
    }
    
}

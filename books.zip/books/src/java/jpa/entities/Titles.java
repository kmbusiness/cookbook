/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Chi Phan
 */
@Entity
@Table(name = "titles")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Titles.findAll", query = "SELECT t FROM Titles t"),
    @NamedQuery(name = "Titles.findByTitleId", query = "SELECT t FROM Titles t WHERE t.titleId = :titleId"),
    @NamedQuery(name = "Titles.findByTitleName", query = "SELECT t FROM Titles t WHERE t.titleName = :titleName"),
    @NamedQuery(name = "Titles.findByType", query = "SELECT t FROM Titles t WHERE t.type = :type"),
    @NamedQuery(name = "Titles.findByPages", query = "SELECT t FROM Titles t WHERE t.pages = :pages"),
    @NamedQuery(name = "Titles.findByPrice", query = "SELECT t FROM Titles t WHERE t.price = :price"),
    @NamedQuery(name = "Titles.findBySales", query = "SELECT t FROM Titles t WHERE t.sales = :sales"),
    @NamedQuery(name = "Titles.findByPubdate", query = "SELECT t FROM Titles t WHERE t.pubdate = :pubdate"),
    @NamedQuery(name = "Titles.findByContract", query = "SELECT t FROM Titles t WHERE t.contract = :contract")})
public class Titles implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "title_id")
    private String titleId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 40)
    @Column(name = "title_name")
    private String titleName;
    @Size(max = 10)
    @Column(name = "type")
    private String type;
    @Column(name = "pages")
    private Integer pages;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "price")
    private BigDecimal price;
    @Column(name = "sales")
    private Integer sales;
    @Column(name = "pubdate")
    @Temporal(TemporalType.DATE)
    private Date pubdate;
    @Basic(optional = false)
    @NotNull
    @Column(name = "contract")
    private short contract;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "titles")
    private Royalties royalties;
    @JoinColumn(name = "pub_id", referencedColumnName = "pub_id")
    @ManyToOne(optional = false)
    private Publishers pubId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "titles")
    private Collection<TitleAuthors> titleAuthorsCollection;

    public Titles() {
    }

    public Titles(String titleId) {
        this.titleId = titleId;
    }

    public Titles(String titleId, String titleName, short contract) {
        this.titleId = titleId;
        this.titleName = titleName;
        this.contract = contract;
    }

    public String getTitleId() {
        return titleId;
    }

    public void setTitleId(String titleId) {
        this.titleId = titleId;
    }

    public String getTitleName() {
        return titleName;
    }

    public void setTitleName(String titleName) {
        this.titleName = titleName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getPages() {
        return pages;
    }

    public void setPages(Integer pages) {
        this.pages = pages;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Integer getSales() {
        return sales;
    }

    public void setSales(Integer sales) {
        this.sales = sales;
    }

    public Date getPubdate() {
        return pubdate;
    }

    public void setPubdate(Date pubdate) {
        this.pubdate = pubdate;
    }

    public short getContract() {
        return contract;
    }

    public void setContract(short contract) {
        this.contract = contract;
    }

    public Royalties getRoyalties() {
        return royalties;
    }

    public void setRoyalties(Royalties royalties) {
        this.royalties = royalties;
    }

    public Publishers getPubId() {
        return pubId;
    }

    public void setPubId(Publishers pubId) {
        this.pubId = pubId;
    }

    @XmlTransient
    public Collection<TitleAuthors> getTitleAuthorsCollection() {
        return titleAuthorsCollection;
    }

    public void setTitleAuthorsCollection(Collection<TitleAuthors> titleAuthorsCollection) {
        this.titleAuthorsCollection = titleAuthorsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (titleId != null ? titleId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Titles)) {
            return false;
        }
        Titles other = (Titles) object;
        if ((this.titleId == null && other.titleId != null) || (this.titleId != null && !this.titleId.equals(other.titleId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpa.entities.Titles[ titleId=" + titleId + " ]";
    }
    
}

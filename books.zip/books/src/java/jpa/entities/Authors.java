/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Chi Phan
 */
@Entity
@Table(name = "authors")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Authors.findAll", query = "SELECT a FROM Authors a"),
    @NamedQuery(name = "Authors.findByAuId", query = "SELECT a FROM Authors a WHERE a.auId = :auId"),
    @NamedQuery(name = "Authors.findByAuFname", query = "SELECT a FROM Authors a WHERE a.auFname = :auFname"),
    @NamedQuery(name = "Authors.findByAuLname", query = "SELECT a FROM Authors a WHERE a.auLname = :auLname"),
    @NamedQuery(name = "Authors.findByPhone", query = "SELECT a FROM Authors a WHERE a.phone = :phone"),
    @NamedQuery(name = "Authors.findByAddress", query = "SELECT a FROM Authors a WHERE a.address = :address"),
    @NamedQuery(name = "Authors.findByCity", query = "SELECT a FROM Authors a WHERE a.city = :city"),
    @NamedQuery(name = "Authors.findByState", query = "SELECT a FROM Authors a WHERE a.state = :state"),
    @NamedQuery(name = "Authors.findByZip", query = "SELECT a FROM Authors a WHERE a.zip = :zip")})
public class Authors implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 3)
    @Column(name = "au_id")
    private String auId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "au_fname")
    private String auFname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "au_lname")
    private String auLname;
    // @Pattern(regexp="^\\(?(\\d{3})\\)?[- ]?(\\d{3})[- ]?(\\d{4})$", message="Invalid phone/fax format, should be as xxx-xxx-xxxx")//if the field contains phone or fax number consider using this annotation to enforce field validation
    @Size(max = 12)
    @Column(name = "phone")
    private String phone;
    @Size(max = 20)
    @Column(name = "address")
    private String address;
    @Size(max = 15)
    @Column(name = "city")
    private String city;
    @Size(max = 2)
    @Column(name = "state")
    private String state;
    @Size(max = 5)
    @Column(name = "zip")
    private String zip;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "authors")
    private Collection<TitleAuthors> titleAuthorsCollection;

    public Authors() {
    }

    public Authors(String auId) {
        this.auId = auId;
    }

    public Authors(String auId, String auFname, String auLname) {
        this.auId = auId;
        this.auFname = auFname;
        this.auLname = auLname;
    }

    public String getAuId() {
        return auId;
    }

    public void setAuId(String auId) {
        this.auId = auId;
    }

    public String getAuFname() {
        return auFname;
    }

    public void setAuFname(String auFname) {
        this.auFname = auFname;
    }

    public String getAuLname() {
        return auLname;
    }

    public void setAuLname(String auLname) {
        this.auLname = auLname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    @XmlTransient
    public Collection<TitleAuthors> getTitleAuthorsCollection() {
        return titleAuthorsCollection;
    }

    public void setTitleAuthorsCollection(Collection<TitleAuthors> titleAuthorsCollection) {
        this.titleAuthorsCollection = titleAuthorsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (auId != null ? auId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Authors)) {
            return false;
        }
        Authors other = (Authors) object;
        if ((this.auId == null && other.auId != null) || (this.auId != null && !this.auId.equals(other.auId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "jpa.entities.Authors[ auId=" + auId + " ]";
    }
    
}

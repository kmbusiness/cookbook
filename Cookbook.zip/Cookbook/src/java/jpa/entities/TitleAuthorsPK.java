/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author allenmuy
 */
@Embeddable
public class TitleAuthorsPK implements Serializable {

  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 3)
  @Column(name = "title_id")
  private String titleId;
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 3)
  @Column(name = "au_id")
  private String auId;

  public TitleAuthorsPK() {
  }

  public TitleAuthorsPK(String titleId, String auId) {
    this.titleId = titleId;
    this.auId = auId;
  }

  public String getTitleId() {
    return titleId;
  }

  public void setTitleId(String titleId) {
    this.titleId = titleId;
  }

  public String getAuId() {
    return auId;
  }

  public void setAuId(String auId) {
    this.auId = auId;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (titleId != null ? titleId.hashCode() : 0);
    hash += (auId != null ? auId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof TitleAuthorsPK)) {
      return false;
    }
    TitleAuthorsPK other = (TitleAuthorsPK) object;
    if ((this.titleId == null && other.titleId != null) || (this.titleId != null && !this.titleId.equals(other.titleId))) {
      return false;
    }
    if ((this.auId == null && other.auId != null) || (this.auId != null && !this.auId.equals(other.auId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "jpa.entities.TitleAuthorsPK[ titleId=" + titleId + ", auId=" + auId + " ]";
  }
  
}

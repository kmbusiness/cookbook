/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author allenmuy
 */
@Entity
@Table(name = "royalties")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "Royalties.findAll", query = "SELECT r FROM Royalties r"),
  @NamedQuery(name = "Royalties.findByTitleId", query = "SELECT r FROM Royalties r WHERE r.titleId = :titleId"),
  @NamedQuery(name = "Royalties.findByAdvance", query = "SELECT r FROM Royalties r WHERE r.advance = :advance"),
  @NamedQuery(name = "Royalties.findByRoyaltyRate", query = "SELECT r FROM Royalties r WHERE r.royaltyRate = :royaltyRate")})
public class Royalties implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @Basic(optional = false)
  @NotNull
  @Size(min = 1, max = 3)
  @Column(name = "title_id")
  private String titleId;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Column(name = "advance")
  private BigDecimal advance;
  @Column(name = "royalty_rate")
  private BigDecimal royaltyRate;
  @JoinColumn(name = "title_id", referencedColumnName = "title_id", insertable = false, updatable = false)
  @OneToOne(optional = false)
  private Titles titles;

  public Royalties() {
  }

  public Royalties(String titleId) {
    this.titleId = titleId;
  }

  public String getTitleId() {
    return titleId;
  }

  public void setTitleId(String titleId) {
    this.titleId = titleId;
  }

  public BigDecimal getAdvance() {
    return advance;
  }

  public void setAdvance(BigDecimal advance) {
    this.advance = advance;
  }

  public BigDecimal getRoyaltyRate() {
    return royaltyRate;
  }

  public void setRoyaltyRate(BigDecimal royaltyRate) {
    this.royaltyRate = royaltyRate;
  }

  public Titles getTitles() {
    return titles;
  }

  public void setTitles(Titles titles) {
    this.titles = titles;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (titleId != null ? titleId.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof Royalties)) {
      return false;
    }
    Royalties other = (Royalties) object;
    if ((this.titleId == null && other.titleId != null) || (this.titleId != null && !this.titleId.equals(other.titleId))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "jpa.entities.Royalties[ titleId=" + titleId + " ]";
  }
  
}

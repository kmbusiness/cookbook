/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jpa.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author allenmuy
 */
@Entity
@Table(name = "title_authors")
@XmlRootElement
@NamedQueries({
  @NamedQuery(name = "TitleAuthors.findAll", query = "SELECT t FROM TitleAuthors t"),
  @NamedQuery(name = "TitleAuthors.findByTitleId", query = "SELECT t FROM TitleAuthors t WHERE t.titleAuthorsPK.titleId = :titleId"),
  @NamedQuery(name = "TitleAuthors.findByAuId", query = "SELECT t FROM TitleAuthors t WHERE t.titleAuthorsPK.auId = :auId"),
  @NamedQuery(name = "TitleAuthors.findByAuOrder", query = "SELECT t FROM TitleAuthors t WHERE t.auOrder = :auOrder"),
  @NamedQuery(name = "TitleAuthors.findByRoyaltyShare", query = "SELECT t FROM TitleAuthors t WHERE t.royaltyShare = :royaltyShare")})
public class TitleAuthors implements Serializable {

  private static final long serialVersionUID = 1L;
  @EmbeddedId
  protected TitleAuthorsPK titleAuthorsPK;
  @Basic(optional = false)
  @NotNull
  @Column(name = "au_order")
  private short auOrder;
  // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
  @Basic(optional = false)
  @NotNull
  @Column(name = "royalty_share")
  private BigDecimal royaltyShare;
  @JoinColumn(name = "au_id", referencedColumnName = "au_id", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private Authors authors;
  @JoinColumn(name = "title_id", referencedColumnName = "title_id", insertable = false, updatable = false)
  @ManyToOne(optional = false)
  private Titles titles;

  public TitleAuthors() {
  }

  public TitleAuthors(TitleAuthorsPK titleAuthorsPK) {
    this.titleAuthorsPK = titleAuthorsPK;
  }

  public TitleAuthors(TitleAuthorsPK titleAuthorsPK, short auOrder, BigDecimal royaltyShare) {
    this.titleAuthorsPK = titleAuthorsPK;
    this.auOrder = auOrder;
    this.royaltyShare = royaltyShare;
  }

  public TitleAuthors(String titleId, String auId) {
    this.titleAuthorsPK = new TitleAuthorsPK(titleId, auId);
  }

  public TitleAuthorsPK getTitleAuthorsPK() {
    return titleAuthorsPK;
  }

  public void setTitleAuthorsPK(TitleAuthorsPK titleAuthorsPK) {
    this.titleAuthorsPK = titleAuthorsPK;
  }

  public short getAuOrder() {
    return auOrder;
  }

  public void setAuOrder(short auOrder) {
    this.auOrder = auOrder;
  }

  public BigDecimal getRoyaltyShare() {
    return royaltyShare;
  }

  public void setRoyaltyShare(BigDecimal royaltyShare) {
    this.royaltyShare = royaltyShare;
  }

  public Authors getAuthors() {
    return authors;
  }

  public void setAuthors(Authors authors) {
    this.authors = authors;
  }

  public Titles getTitles() {
    return titles;
  }

  public void setTitles(Titles titles) {
    this.titles = titles;
  }

  @Override
  public int hashCode() {
    int hash = 0;
    hash += (titleAuthorsPK != null ? titleAuthorsPK.hashCode() : 0);
    return hash;
  }

  @Override
  public boolean equals(Object object) {
    // TODO: Warning - this method won't work in the case the id fields are not set
    if (!(object instanceof TitleAuthors)) {
      return false;
    }
    TitleAuthors other = (TitleAuthors) object;
    if ((this.titleAuthorsPK == null && other.titleAuthorsPK != null) || (this.titleAuthorsPK != null && !this.titleAuthorsPK.equals(other.titleAuthorsPK))) {
      return false;
    }
    return true;
  }

  @Override
  public String toString() {
    return "jpa.entities.TitleAuthors[ titleAuthorsPK=" + titleAuthorsPK + " ]";
  }
  
}
